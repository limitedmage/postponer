ISRIL_SCRIPT=document.createElement('SCRIPT');
ISRIL_SCRIPT.type='text/javascript';
ISRIL_SCRIPT.src='http://readitlaterlist.com/b/r.js';
document.getElementsByTagName('head')[0].appendChild(ISRIL_SCRIPT);